const mongoose = require('mongoose');


//define a schema for user
const UserSchema = new mongoose.Schema({

    //Fields for users(supporters and observers)
    firstName: String,
    surname: String,
    email: String, 
    password : String,
    address : String,
    category : String,
    status : String,
    sendMessage : String,
    receiveMessage : String,
    //Fields for Observers(Bank Details)
    accountBalance: Number,
    creditCardNumber: String,
    nameOnCard: String,
    creditCardType: { type: String, enum: ['Visa', 'Mastercard'] },
    creditCardCVV: String,
    notificationPreference: { type: String, enum: ['text', 'email'] },
    //Observation Details from Observers
    date:String,
    time:String,
    timezone: String,
    coordinatesW3W: Number,
    coordinatesDecimal: Number,
    landSurfaceTemp: Number,
    seaSurfaceTemp: Number,
    humidity: Number,
    windSpeed: Number,
    windDirection : Number,
    precipitation:Number,
    haze:Number,
    notes:String
});



const User = mongoose.model('sysusers', UserSchema);


module.exports = mongoose.model('sysusers', UserSchema);


