const { request } = require('http');
const user = require('../models/user');

module.exports = function (app) {
    //connect to the database using the details from the dbconfig file
    const mongoose = require('../config/dbconfig')
    const User = require('../models/user')
    const detailsUser = require('../models/user')

    //to serve static files from current location, determine parent directory
    const path = require("path");
    const parentDirectory = path.dirname(__dirname)

    const bcrypt = require('bcrypt');
    const saltRounds = 10

            



//Rendering the HomePage for both Get and Post requsts to the root URL
    app.get('/', (req, res) => {
        res.render('HomePage')

    })

    
    app.post('/', (req, res) => {
        res.render('HomePage')

    })


    // Retrieve user data and render the 'getusers' view with the query result
app.get('/users/getusers' , async (req,res) => {
        try{
            const qryRes = await User.find();
            res.render("getusers", {users: qryRes})
        }
        catch(error){
            res.status(500).json({message : error.message})
        }

        })





// Render the 'register' view for GET requests to '/register'
app.get('/register', (req, res) => {
    res.render('register'); 
});




app.get('/getUserData',  async (req, res) => {

    try {


     const userData = await User.findOne({ email: req.session.user.email });


    res.render("getUserData",{users : userData})

    } catch (error) {


        console.error('There has been error getting the info, try again', error);
        res.status(500).send("Oops, looks like there is a crash, try again");
    }
});




app.get('/users/getuserdata/:id', async (req, res) => {
    try {
        const qryRes = await User.findById(req.params.id);


        res.render("getuserdata", { users: qryRes });
    } catch (error) {

        res.status(500).json({ message: error.message });
    }
});

app.post('/register', async (req, res) => {
    try {


        const hash = await bcrypt.hash(req.body.password, saltRounds);
        console.log(`Result of hashing ${req.body.password} is --> ${hash}`);


        const newUser = new User({
            firstName: req.body.firstName,
            surname: req.body.surname,
            email: req.body.email,
            password: hash,
            address: req.body.address,
            category: req.body.category,
            status: "Active"
        });



        await newUser.save();
        console.log('The user has been able to be registered');
        res.redirect('/login');
    } catch (error) {


        if (error.name === 'Database Error occured' && error.code === 11000 && error.keyPattern.email) {


            return res.status(400).send("Email address is already in use");
        }


        console.error('Error registering user:', error);
        res.status(500).send("Oops, looks like there is a crash, try again")
    }
});



// Get all users and render the 'getusers' view
app.get('/users/getusers' , async (req,res) => 
    {
    try{
        const qryRes = await User.find();


        res.render("getusers", {users: qryRes})
    }


    catch(error){
    // Here we are basically handling errors by sending a 500 JSON response with the error message, you can add anything to the error and we are going to keep repeating this in the following code.       res.status(500).json({message : error.message})
    }

})


//Rendering the login page like we rendered the homepage before
app.get('/login', (req,res) =>{



    res.render('login')

})


// Handle login POST requests
app.post('/login', async (req, res) => {
    console.log(`Email: ${req.body.email}`);


    console.log(`Password: ${req.body.password}`);


    try {

        //Here basically I am trying trying to find the user by email 
        const qryRes = await User.findOne({ email: req.body.email }).exec();


        if (!qryRes) {
            return res.status(401).send("User not found");
        }


        // Here we are basically comparing password hashes and telling the program to give a specific error if the password is incorrect.
        bcrypt.compare(req.body.password, qryRes.password, function (err, result) {

            if (err) {
                console.error("The entered password is incorrect.:", err);


                return res.status(500).send("Oops, looks like there is a crash, try again")
            }


            console.log(`Result of comparison is --> ${result}`);

            // If the password does match, system will store user data in session
            if (result) {

                req.session.user = { 
                    email: qryRes.email,
                    

                    password: qryRes.password,
                };




                    if (qryRes.category === "observer") {

                    res.render('observerOptions');




                } else if (qryRes.category === "support") {



                    res.render(`supportOptions`)


                } else {


                    res.status(400).send("Invalid category");


                }
            } else {


                res.status(401).send("Unauthorized");
            }
        });
        // Here again I am putting the 500 response of JSON that handles errors just like previously done
    } catch (error) {



        console.error("There's been an issue logging in try again", error);



        res.status(500).send("Oops, looks like there is a crash, try again");
    }
});



// Here user is trying get user data by ID and render the 'getuserdata' view
app.get('/users/getuserdata/:id', async (req, res) => {
    try {
        // Finding the user by ID
        const qryRes = await User.findById(req.params.id);
        // Render the 'getuserdata' view with the user data
        res.render("getuserdata", { users: qryRes });
    } catch (error) {
        // Handle errors by sending a 500 JSON response with the error message
        res.status(500).json({ message: error.message });
    }
});





// Render the 'observeroptions' view
app.get('/observeroptions', (req, res) => {
    res.render('observeroptions');
});

// Handle observer options POST requests
app.post('/observeroptions', (req, res) => {
});

    

    // Render the 'observeroptions' view for POST requests
app.post('/observeroptions', (req, res) => {
    res.render('observeroptions');
});

// Render the 'updateUser' view
app.get('/updateUser', (req, res) => {
    res.render('updateUser');
});

app.post('/updateUserData',  async (req, res) => {
    try {
        const user = await User.findOne({ email: req.session.user.email });


        bcrypt.hash(req.body.password, saltRounds, function (err, hash){
        user.firstName = req.body.firstName;

        user.surname = req.body.surname;

        user.email = req.body.email;

        user.password = hash;
        user.address = req.body.address;


     

        user.save();

        res.status(200).send("User details have been able to be updated");
        });



    } catch (error) {
        console.error("There has been error updating your information", error);

        res.status(500).send(('Database Error occured'));
    }
});



app.get('/bankDetails', async (req, res) =>{
    res.render('bankDetails');
})

app.post('/bankDetails', async (req, res) => {
    try {
        const { accountBalance, 
                creditCardNumber,
                nameOnCard,
                creditCardType, 
                creditCardCVV, 
                notificationPreference } = req.body;


        if (!req.session.user || !req.session.user.email) {
            return res.status(400).send('User email not found in session');
        }

        // Find the user by email
        let userDetails = await User.findOne({ email: req.session.user.email });

        if (!userDetails) {
            userDetails = new User({
                email: req.session.user.email,
                accountBalance,
                creditCardNumber,
                nameOnCard,
                creditCardType,
                creditCardCVV,
                notificationPreference
            });

            // Save the user Details
            await userDetails.save();
        } else {
            // Update observer details
            userDetails.accountBalance = accountBalance;
            userDetails.creditCardNumber = creditCardNumber;
            userDetails.nameOnCard = nameOnCard;
            userDetails.creditCardType = creditCardType;
            userDetails.creditCardCVV = creditCardCVV;
            userDetails.notificationPreference = notificationPreference;

            // Save the updated user Details
            await userDetails.save();
        }

        
        res.render("showBankDetails", { userDetails });

    } catch (error) {
        console.error('Error saving observer details:', error);
        res.status(500).send('Internal Server Error/Not Logged in');
    }
});




   
app.get('/showBankDetails', async (req, res) => {
    try {

        console.log('Session user:', req.session.user.email);
    
        let userDetails = await User.findOne({ email: req.session.user.email });

        res.render("showBankDetails", { userDetails });

        


        if (!userDetails) {
            return res.status(404).send('User details not found');
        }


    } catch (error) {
        console.error('Error retrieving data:', error);
        res.status(500).send('Internal Server Error/Not Logged in');
    }
});



app.get('/userObservation', async (req, res) =>{
    res.render('userObservation');
})

app.post('/userObservation', async(req,res)=>{
    try {
        const { date, 
                time,
                timezone,
                coordinatesW3W,
                temperature,
                precipitation,
                notes} = req.body;

                console.log('req.session.user:', req.session.user.email);


        if (!req.session.user || !req.session.user.email) {
            return res.status(400).send('User email not found in session');
        }

        

        const observationDetails = await User.findOne({ email: req.session.user.email });


        if (!observationDetails) {

            observationDetails = new User({
                email: req.session.user.email,
                date,
                time,
                timezone,
                temperature,
                coordinatesW3W,
                precipitation,
                notes
            });

            observationDetails.save();
        } else {


            observationDetails.date = date;
            observationDetails.time = time;
            observationDetails.timezone = timezone;
            observationDetails.timezone = timezone;
            observationDetails.temperature = temperature;
            observationDetails.precipitation = precipitation;
            observationDetails.notes = notes;
            

            await observationDetails.save();
        }



        res.render("showUserObservation", {observationDetails});


        
    } catch (error) {

        console.error('There has been an error, try again:', error);

        res.status(500).send('Oops, looks like there has been a crash, try again');
    }
});


    app.get('/showUserObservation', async (req, res) => {
        try {


            console.log('Session user:', req.session.user.email);


            const observationDetails = await User.findOne({ email: req.session.user.email });

           

    
            if (!observationDetails) {


                return res.status(404).send('User details not found');
            }
    
    



        res.render("showUserObservation", { observationDetails  });


        } catch (error) {
            console.error("An error just occured collecting the information:", error);

            

            res.status(500).send("An error occured with the email address");
        }
    });


    app.get('/toSendMessageToSupport', async (req, res) => {
        try {
            
            res.render("toSendMessageToSupport");
        } catch (error) {
            console.error('There has been error with toSendMessageToSupport:', error);
            res.status(500).send('Internal Server Error');
        }
    });
    
    app.post('/toSendMessageToSupport', async (req, res) => {
        try {
            const { sendMessage } = req.body;
    
            
            if (!req.session.user || !req.session.user.email) {
                return res.status(400).send('User email not found in session');
            }
    
            // Find the user by email
            let userDetails = await User.findOne({ email: req.session.user.email });
    
            if (!userDetails) {
                // If user details not found, create a new user
                userDetails = new User({
                    email: req.session.user.email,
                    sendMessage
                });
    
                // Save the new user
                await userDetails.save();
            } else {
                // Update observer details
                userDetails.sendMessage = sendMessage;
    
                // Save the updated user
                await userDetails.save();
            }
    
         
            res.redirect("/displayingMessageToSupport");
        } catch (error) {
            console.error('Error saving observer details:', error);
            res.status(500).send('Internal Server Error/Not Logged in');
        }
    });
    




    app.get('/displayingMessageToSupport', async (req, res) => {
        try {
         

            const userDetails = await User.findOne({ email: req.session.user.email });
    




            res.render("displayingMessageToSupport", { userDetails });
        } catch (error) {


            console.error('Unable to retrieve user details:', error);


            res.status(500).send('An issue just occured with the server, try again');
        }
    });
    


   

    app.get('/logout', (req,res) =>{

        res.redirect('login')

    })
  
   
}