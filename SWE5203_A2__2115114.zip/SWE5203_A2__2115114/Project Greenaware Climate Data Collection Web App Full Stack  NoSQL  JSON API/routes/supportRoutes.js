// Importing required modules and models
const { request } = require('http');
const user = require('../models/user');




// Exporting the module function
module.exports = function (app) {
    // This setting is basically the same the one I did in userroutes, I import the necessary configuration and models.
    const mongoose = require('../config/dbconfig')
    const User = require('../models/user')
    const detailsUser = require('../models/user')




    const path = require("path");
    const parentDirectory = path.dirname(__dirname)

    const bcrypt = require('bcrypt');
    const saltRounds = 10





    app.get('/register-support', (req, res) => {


        res.render('register-support');
    });
    
    
    app.post('/register-support', async (req, res) => 
        {
        try {
    
    
            const hash = await bcrypt.hash(req.body.password, saltRounds);
    
    
            console.log(`Result of hashing ${req.body.password} is --> ${hash}`);
    
            const newUser = new User({
                
                name: req.body.firstName,
                surname: req.body.surname,
                email: req.body.email,
                password: hash,
                address: req.body.address,
                category: req.body.category,
                status: "Active"
            });
    
            await newUser.save();
    
    
            console.log('The user has been able to be registered');
    
    
            
            
            res.render('supportoptions');
    
    
        } catch (error) {
    
    
    
            if (error.name === 'Database Error occured' && error.code === 11000 && error.keyPattern.email) {
    
    
    
                return res.status(400).send("The email address enteres is already in use");
            }
    
    
            console.error('Error registering user:', error);
    
    
            res.status(500).send ('Database Error occured')
        }
    });
    

    // Here I basically am just rendering the viewClientDetails view which is just ot see the client details
    app.get('/viewClientDetails', (req, res) => {
        // Render the clientDetails.ejs file
        res.render('viewClientDetails');
    });
  
    app.post('/viewClientDetails', async (req, res) => {
        try {


    
           
            const userData = await User.findOne({ 
                email: req.body.email
            });
    
            if (!userData) {
                // If user data is not found, send an error response
                return res.status(404).send('User not found');
            }
    

    
            // If user data is found, render the page to display the retrieved data
            res.render("getuserdata", { users: userData });
        } catch (error) {
            console.error('Error retrieving data:', error);
            res.status(500).send('Internal Server Error');
        }
    });
    




   // Route for rendering the full table with all observer users
app.get('/fullTableWithAllObservers', async (req, res) => {
    try {
        // Find all observer users
        const qryRes = await User.find({ category: "observer" }).exec();
        // If no observer users found, send a 404 response
        if (!qryRes || qryRes.length === 0) {
            return res.status(404).json({ message: "No observer users found" });
        }
        // Render the 'fullTableWithAllObservers' view with observer user data
        return res.render('fullTableWithAllObservers', { users: qryRes });
    } catch (error) {

        // Log and handle errors by sending a 500 response with an error message
        return res.status(500).json({ message: error.message });
    }
});

// Route for rendering the full table with all support users
app.get('/fullTableWithAllSupport', async (req, res) => {
    try {
        // Find all support users
        const qryRes = await User.find({ category: "support" }).exec();
        // If no support users found, send a 404 response
        if (!qryRes || qryRes.length === 0) {
            return res.status(404).json({ message: "No support users found" });
        }
        // Render the 'fullTableWithAllSupport' view with support user data
        return res.render('fullTableWithAllSupport', { users: qryRes });
    } catch (error) {
        // Log and handle errors by sending a 500 response with an error message
        return res.status(500).json({ message: error.message });
    }
});


  app.get('/viewClientDetails', (req, res) => {
        // Render the clientDetails.ejs file
        res.render('viewClientDetails');
    });
  
    app.post('/viewClientDetails', async (req, res) => {
        try {


    
           
            const userData = await User.findOne({ 
                email: req.body.email
            });
    
            if (!userData) {
                // If user data is not found, send an error response
                return res.status(404).send('User not found');
            }
    

    
            // If user data is found, render the page to display the retrieved data
            res.render("getuserdata", { users: userData });
        } catch (error) {
            console.error('Error retrieving data:', error);
            res.status(500).send('Internal Server Error');
        }
    });
    

    app.get('/changeClientDetails2', (req, res) => {
        // Render the clientDetails.ejs file
        res.render('changeClientDetails2');
    });
    app.post('/changeClientDetails2', async (req, res) => {
        try {
            // Retrieve user data from the database based on the provided surname, forename, and email
            const userData = await User.findOne({ 
                email: req.body.email
            });
    
            if (!userData) {
             
                return res.status(404).send('User not found');
            }

            res.render("changeClientDetails");
        } catch (error) {
            console.error('Error retrieving data:', error);
            res.status(500).send('Internal Server Error/Not Logged in');
        }
    });

    app.get('/changeClientDetails', (req, res) => {

        res.render('changeCientDetails');
    });
    app.post('/changeCientDetails', async (req, res) => {
        try {
            const user2 = await User.findOne({ email: req.body.email });
            bcrypt.hash(req.body.password, saltRounds, async function (err, hash) {
                if (err) {
                    console.error('Error hashing password:', err);
                    return res.status(500).send('Internal Server Error');
                }
                user2.forename = req.body.forename;
                user2.surname = req.body.surname;
                user2.email = req.body.email;
                user2.password = hash;
                user2.address = req.body.address;
                user2.category = req.body.category;
                user2.status = req.body.status;
                // Save the updated user document
                await user2.save();
                // Send a success response
                res.status(200).send("User details updated successfully");
            });
        } catch (error) {
            console.error('Error updating user details:', error);
            res.status(500).send('Internal Server Error/Not Logged in');
        }
    });



// Route for rendering the 'changeObserverStatus' view
app.get("/changeObserverStatus", (req, res) => {
    res.render('changeObserverStatus'); 
});




// Route for handling POST requests to change observer status
app.post("/changeObserverStatus", async (req, res) => {
    try {


        // Retrieve email and status from request body
        const userEmail = req.body.email;
        const userStatus = req.body.status;




        // Here i am fidnding user by email and if nout found below is the error
        const user = await User.findOne({ email: userEmail });




        // If user not found, send a 404 response
        if (!user) {
            return res.status(404).send('User not found');
        }

        // Update user status and then save it below with await user.save
        user.status = userStatus;
        
        await user.save();




        // Render the 'observerStatus' view with updated user status
        res.render('observerStatus',{userStatus : user});
    } catch (error) {
        // Log and handle errors by sending a 500 response with an error message
        console.error('Error updating user status:', error);
        res.status(500).send("Oops, looks like there is a crash, try again");
    }
});

    


  // Route for rendering the 'getObserverDetails' view and fetching observer details
app.get('/getObserverDetails', async (req, res) => {


    try {

        // Here i will get user data from the databse based on the email I will put
        let userDetails = await User.findOne({ email: req.session.user.email });



        // Render the 'getObserverDetails' view with user details
        res.render("getObserverDetails", { userDetails });


        
        // If user details have not been able to be found, systemsend a 404 response
        if (!userDetails) {
            return res.status(404).send('User details not found');
        }



    } catch (error) {
        // Here again we are handling errors by sending a 500 of JSON
        console.error('Error retrieving data:', error);
        res.status(500).send("Oops, looks like there is a crash, try again");
    }
});




app.get('/getQueries', async (req, res) => {
    try {

        
        const allQueries = await User.find();

       

        res.render("getQueries", { allQueries });



    } catch (error) {
        console.error('Error storing user details:', error);


        res.status(500).send("Oops, looks like there is a crash, try again");
    }
});



app.get('/toSendMessageToObserver', async (req, res) => {
    try {

        res.render("toSendMessageToObserver");
    } catch (error) {
        console.error('Error rendering sendMessageToObserver:', error);
        res.status(500).send('An error just occured, try again');
    }
});
app.post('/toSendMessageToObserver', async (req, res) => {
    try {
        const { receiveMessage } = req.body;


        if (!req.session.user || !req.session.user.email) {
            return res.status(400).send("Email not existing");
        }

        // Find the user by email
        let userDetails = await User.findOne({ email: req.session.user.email });

        if (!userDetails) {

            userDetails = new User({
                email: req.session.user.email,
                receiveMessage
            });

            // Save the new user
            await userDetails.save();
        } else {
            // Update observer details
            userDetails.receiveMessage = receiveMessage;

            await userDetails.save();
        }


        res.redirect("/displayingMessageToObserver");
    } catch (error) {
        console.error('There ahs been a problem storing the data, try again', error);
        res.status(500).send('An error just occured, try again');
    }
});

app.get('/displayingMessageToObserver', async (req, res) => {
    try {
        
        
        const userDetails = await User.findOne({ email: req.session.user.email });

       
        res.render("displayingMessageToObserver", { userDetails });
    } catch (error) {
        console.error('There has been a problem storing the data:', error);
        res.status(500).send('An error just occured, try again');
    }
});


app.get('/displayingMessageToSupport', async (req, res) => {
    try {
     
        const userDetails = await User.findOne({ email: req.session.user.email });


        res.render("displayingMessageToSupport", { userDetails });
    } catch (error) {
        console.error('An error just occured, try again', error);
        res.status(500).send('An error just occured, try again');
    }
});


;



 app.get('/observerOptionsMenu', (req,res) => {
        res.render('observeroptions')
        })
app.post('/observerOptionsMenu',(res,req)=>{
        res.render('observeroptionsMenu')
        })



app.get('/supportOptionsMenu', (req,res) => {
         res.render('supportoptions')
        })
app.post('/supportOptionsMenu',(res,req)=>{
            res.render('supportoptions')
        })
    

};