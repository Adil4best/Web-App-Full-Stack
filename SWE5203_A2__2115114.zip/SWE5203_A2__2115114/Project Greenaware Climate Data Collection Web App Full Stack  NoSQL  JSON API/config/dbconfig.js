const mongoose = require('mongoose');
const mongoDB = "mongodb+srv://adilbolton:barcelona2024@cluster0.btc6xlq.mongodb.net/University";

const app =('express')


mongoose.connect(mongoDB);



module.exports = mongoose;

mongoose.connect(mongoDB, {useNewUrlParser: true, useUnifiedTopology: true});

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));